#!/usr/bin/env python3
"""N02 v1.2 只读实时进度页（Python 标准库，无第三方依赖）。

对外接口：
  GET /                     单文件中文进度页（n02_v12_monitor.html）
  GET /api/status           所有已知 run 的 status 快照 + 部署状态 + GPU/CPU 采样
  GET /api/history?run_id=  该 run 的 history.jsonl（JSON 数组）
  GET /api/preview?run_id=&file=   该 run 目录内的预览图片文件

安全边界：
  * 只读 <run-root>/<stage>/<run_id>，stage ∈ {P2,P3,P4}，run_id 必须匹配 ^[A-Za-z0-9._-]+$；
    解析后的真实路径必须落在 run-root 内（挡住 ..、绝对路径与软链接逃逸）。
  * 响应只包含固定字段白名单，训练端写入 status.json 的其他字段（可能含凭据）不会回显。
  * 只监听 127.0.0.1。

部署：supervisor 程序 owac-n02-v12-monitor（默认 127.0.0.1:18080；
用户经 SSH -L 8081:localhost:18080 访问）。
"""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

DEFAULT_RUN_ROOT = "/workspace/owac/worktrees/n02-measurement-completion/outputs/n02-v12"
DOWNLOAD_STATUS_PATH = "/workspace/owac/deployment/downloads.json"

STAGES = ("P2", "P3", "P4")
RUN_ID_RE = re.compile(r"^[A-Za-z0-9._-]+$")
STALE_SECONDS = 30.0
IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".svg"}
LOG_TAIL_LINES = 30
LOG_LINE_CHARS = 500
HISTORY_MAX_RECORDS = 20000
GPU_SAMPLE_SECONDS = 10.0
DEPLOYMENT_REFRESH_SECONDS = 10.0

# 只有这些字段会出现在 /api/status 里（其余一律不回显）。
STATUS_FIELDS = (
    "run_id",
    "stage",
    "arm",
    "platform",
    "seed",
    "state",
    "activity",
    "gpu",
    "step",
    "target_steps",
    "updated_at",
    "started_at",
    "step_seconds",
    "loss",
    "dev_action_error",
    "checkpoint",
    "eval",
    "log_tail",
)

RUNNING_STATES = {"running", "run", "train", "training", "in_progress", "busy"}
DONE_STATES = {"done", "complete", "completed", "finished", "success", "succeeded"}
ERROR_STATES = {"error", "failed", "failure", "crashed", "exception"}

SLOT_ALIASES = (
    ("attention", ("attention", "attn", "heatmap", "heat_map", "overlay", "saliency")),
    ("residual", ("residual", "resid", "diff", "delta", "error_map", "errormap")),
    ("raw", ("raw", "bayer", "cfa", "hdr")),
    ("rgb", ("rgb", "srgb", "color", "colour")),
)
CAMERA_KEYS = ("camera", "camera_id", "cam", "camera_name")
FRAME_KEYS = ("frame", "frame_id", "frame_index")
LOOP_KEYS = ("inner_loop", "loop", "loop_index", "inner")

_LOCK = threading.Lock()
_STATE: dict = {
    "gpus": [],
    "gpu_sampled_at": None,
    "cpu": None,
    "deployment": {},
    "deployment_updated_at": None,
    "server_started_at": None,
}


def utc_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def parse_iso(value):
    """把 ISO8601（Z 或 +00:00）解析成 epoch 秒；失败返回 None。"""
    if not isinstance(value, str) or not value:
        return None
    text = value.strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        from datetime import datetime

        return datetime.fromisoformat(text).timestamp()
    except ValueError:
        return None


def run_root() -> Path:
    return Path(os.environ.get("N02_V12_RUN_ROOT") or DEFAULT_RUN_ROOT)


def resolve_run_dir(root: Path, stage, run_id):
    """白名单校验：返回 (run_dir, None) 或 (None, 拒绝原因)。"""
    if stage not in STAGES:
        return None, "unknown stage"
    if not isinstance(run_id, str) or not RUN_ID_RE.match(run_id) or run_id in (".", ".."):
        return None, "invalid run_id"
    root_real = Path(os.path.realpath(root))
    candidate = Path(os.path.realpath(root_real / stage / run_id))
    if candidate != root_real and root_real not in candidate.parents:
        return None, "path escapes run root"
    if not candidate.is_dir():
        return None, "run not found"
    return candidate, None


def _as_float(value):
    try:
        out = float(value)
    except (TypeError, ValueError):
        return None
    return out


def _state_kind(state) -> str:
    text = str(state or "").strip().lower()
    if text in RUNNING_STATES:
        return "running"
    if text in DONE_STATES:
        return "done"
    if text in ERROR_STATES:
        return "error"
    return "idle" if not text else "other"


def _classify(key, name) -> str:
    for source in (str(key or "").lower(), str(name or "").lower()):
        for slot, aliases in SLOT_ALIASES:
            if any(alias in source for alias in aliases):
                return slot
    return "other"


def _preview_url(run_id: str, relative: str) -> str:
    return "/api/preview?run_id={}&file={}".format(
        urllib.parse.quote(run_id, safe=""), urllib.parse.quote(relative, safe="")
    )


def _tile_entry(run_id: str, relative) -> dict:
    text = str(relative).strip()
    if not text:
        return {}
    name = text.rsplit("/", 1)[-1]
    return {"name": name, "url": _preview_url(run_id, text), "path": text}


def normalize_previews(run_id, raw):
    """把训练端写的 preview_files（dict / 嵌套 dict / 记录列表）归一成前端结构。"""
    empty = {"options": {"cameras": [], "frames": [], "loops": []}, "tiles": [], "other": []}
    if not raw:
        return empty

    tiles: list[dict] = []
    other: list[dict] = []
    options = {"cameras": [], "frames": [], "loops": []}

    def new_tile(camera=None, frame=None, loop=None):
        return {
            "camera": camera,
            "frame": frame,
            "loop": loop,
            "slots": {s: [] for s, _ in SLOT_ALIASES},
        }

    def add(tile, key, value):
        entries = value if isinstance(value, (list, tuple)) else [value]
        for entry in entries:
            if isinstance(entry, dict):
                entry = entry.get("path") or entry.get("file") or entry.get("url")
            if not isinstance(entry, str) or not entry.strip():
                continue
            slot = _classify(key, entry)
            item = _tile_entry(run_id, entry)
            if slot == "other":
                other.append({"key": str(key or ""), **item})
            else:
                tile["slots"][slot].append(item)

    def fill(tile, mapping):
        for key, value in mapping.items():
            if key in CAMERA_KEYS + FRAME_KEYS + LOOP_KEYS:
                continue
            if isinstance(value, dict):
                nested = dict(value)
                nested.setdefault("camera", key)
                fill(new_tile_from(nested), value)
            else:
                add(tile, key, value)

    def new_tile_from(mapping):
        tile = new_tile(
            mapping.get("camera") or mapping.get("cam") or mapping.get("camera_id"),
            None,
            None,
        )
        for key in FRAME_KEYS:
            if key in mapping:
                tile["frame"] = mapping[key]
                break
        for key in LOOP_KEYS:
            if key in mapping:
                tile["loop"] = mapping[key]
                break
        tiles.append(tile)
        return tile

    if isinstance(raw, dict):
        flat = new_tile()
        for key, value in raw.items():
            if isinstance(value, dict):
                fill(new_tile_from({"camera": key}), value)
            else:
                add(flat, key, value)
        if any(flat["slots"].values()):
            tiles.append(flat)
    elif isinstance(raw, (list, tuple)):
        for item in raw:
            if isinstance(item, dict) and any(
                key in item for key in ("raw", "rgb", "attention", "residual")
            ):
                fill(new_tile_from(item), item)
            elif isinstance(item, dict):
                for key, value in item.items():
                    add(new_tile(), key, value)
            else:
                add(new_tile(), "", item)

    for tile in tiles:
        for slot, values in (("camera", "cameras"), ("frame", "frames"), ("loop", "loops")):
            value = tile[slot]
            if value is not None and value not in options[values]:
                options[values].append(value)

    return {"options": options, "tiles": tiles, "other": other[:8]}


def _log_tail(value):
    if isinstance(value, str):
        lines = value.splitlines()
    elif isinstance(value, (list, tuple)):
        lines = []
        for item in value:
            lines.extend(str(item).splitlines() or [""])
    else:
        return []
    out = [line[:LOG_LINE_CHARS] for line in lines if line.strip()][-LOG_TAIL_LINES:]
    return out


def is_sample_run(run_id: str, payload: dict) -> bool:
    if payload.get("ui_test") is True or payload.get("sample") is True:
        return True
    return str(run_id).startswith("ui-sample")


def _gpu_candidates(declared):
    """把训练端写的 gpu 字段归一成待匹配的 token 列表。

    训练端实际写法是 dict（如 {"cuda_visible_devices": "1", "device": "cuda", ...}），
    也兼容 int / "0,1" / 列表；无法解析（例如 GPU UUID）时返回空列表，交给 arm 规则兜底。
    """
    if isinstance(declared, dict):
        for key in ("cuda_visible_devices", "device_index", "index", "id", "gpu"):
            if key in declared:
                return _gpu_candidates(declared[key])
        return []
    if isinstance(declared, (list, tuple)):
        tokens: list[str] = []
        for item in declared:
            tokens.extend(_gpu_candidates(item))
        return tokens
    if declared is None or declared == "":
        return []
    return [part.strip() for part in str(declared).replace(";", ",").split(",") if part.strip()]


def _match_gpus(gpus, run_id, arm, declared):
    """按 status.gpu 匹配；没写就按 arm（raw→0 / rgb→1）推断，并标明来源。"""
    out: list[dict] = []
    wanted: list[int] = []
    for item in _gpu_candidates(declared):
        num = _as_float(item)
        if num is not None and float(num).is_integer():
            wanted.append(int(num))
    assigned_by = "status"
    if not wanted:
        arm_text = str(arm or "").lower()
        if "raw" in arm_text and len(gpus) >= 1:
            wanted, assigned_by = [0], "arm"
        elif "rgb" in arm_text and len(gpus) >= 2:
            wanted, assigned_by = [1], "arm"
        else:
            return []
    for gpu in gpus:
        if gpu.get("index") in wanted:
            out.append({**gpu, "assigned_by": assigned_by})
    return out


def load_run(root: Path, stage: str, run_id: str):
    run_dir, error = resolve_run_dir(root, stage, run_id)
    if run_dir is None:
        return None
    try:
        payload = json.loads((run_dir / "status.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        payload = {}
    if not isinstance(payload, dict):
        payload = {}

    with _LOCK:
        gpus = list(_STATE["gpus"])
    record = {field: payload.get(field) for field in STATUS_FIELDS}
    record["run_id"] = payload.get("run_id") or run_id
    record["stage"] = payload.get("stage") or stage
    record["is_sample"] = is_sample_run(run_id, payload)
    record["dir_name"] = run_id
    record["state_kind"] = _state_kind(payload.get("state"))
    record["log_tail"] = _log_tail(payload.get("log_tail"))
    record["previews"] = normalize_previews(run_id, payload.get("preview_files"))
    record["gpu_detail"] = _match_gpus(gpus, run_id, payload.get("arm"), payload.get("gpu"))
    record["history_available"] = (run_dir / "history.jsonl").is_file()
    record["has_status"] = (run_dir / "status.json").is_file()
    updated = parse_iso(payload.get("updated_at"))
    record["age_seconds"] = round(time.time() - updated, 1) if updated else None
    record["stale"] = bool(updated is None or (time.time() - updated) > STALE_SECONDS)
    started, steps = parse_iso(payload.get("started_at")), _as_float(payload.get("step"))
    target, speed = _as_float(payload.get("target_steps")), _as_float(payload.get("step_seconds"))
    elapsed = (updated - started) if (updated and started) else None
    record["elapsed_seconds"] = round(elapsed, 1) if elapsed and elapsed > 0 else None
    if (
        steps is not None
        and target is not None
        and speed is not None
        and target > steps
        and speed > 0
    ):
        record["eta_seconds"] = round((target - steps) * speed, 1)
    else:
        record["eta_seconds"] = None
    return record


def snapshot_runs(root: Path):
    records: list[dict] = []
    for stage in STAGES:
        stage_dir = root / stage
        if not stage_dir.is_dir():
            continue
        try:
            entries = sorted(os.listdir(stage_dir))
        except OSError:
            continue
        for run_id in entries:
            if not RUN_ID_RE.match(run_id) or run_id in (".", ".."):
                continue
            if not (stage_dir / run_id).is_dir():
                continue
            if not (stage_dir / run_id / "status.json").is_file():
                continue  # 只列出真正的 run：没有 status.json 的目录（临时/工作目录）不算作业
            record = load_run(root, stage, run_id)
            if record:
                records.append(record)
    records.sort(
        key=lambda item: (
            item["age_seconds"] is None,
            item["age_seconds"] or 0.0,
            item["dir_name"],
        )
    )
    return records


def _fresh_running_real(records):
    return [
        item
        for item in records
        if not item["is_sample"]
        and item["age_seconds"] is not None
        and item["state_kind"] == "running"
        and not item["stale"]
    ]


def _newest(records):
    return min(
        records,
        key=lambda item: item["age_seconds"] if item["age_seconds"] is not None else 1e9,
    )


def _primary_key(item):
    """主作业排序键（越小越优先）：真实优先 → 目标步数大 → 开始时间早 → 心跳新。

    同一个键跨所有 tier 使用，所以「正式训练 vs -profile 侧跑」「RAW 主臂 vs RGB 对照臂」
    按同一套语义选，不取决于哪个 run 恰好最后写盘。
    """
    target = _as_float(item.get("target_steps"))
    started = parse_iso(item.get("started_at"))
    age = item["age_seconds"] if item["age_seconds"] is not None else float("inf")
    return (
        0 if not item["is_sample"] else 1,
        -target if target is not None else float("inf"),
        started if started is not None else float("inf"),
        age,
    )


def _primary_of(records):
    """挑「主作业」：先看新鲜运行中的真实 run，再退到有数据的真实 run / 有数据的 run / 全部。"""
    if not records:
        return None
    groups = (
        _fresh_running_real(records),
        [item for item in records if not item["is_sample"] and item["age_seconds"] is not None],
        [item for item in records if item["age_seconds"] is not None],
        records,
    )
    for group in groups:
        if group:
            return min(group, key=_primary_key)["dir_name"]
    return None


def _pick(records, predicate):
    return _primary_of([item for item in records if predicate(item)])


def build_display(records) -> dict:
    """页面选择规则：先要有 status.json（age_seconds 非空），再优先真实作业，
    最后才轮到无数据的目录。

    运行根下可能出现别的 agent 建的临时目录（不是 run），不能让它们把页面顶成空白。
    """
    current = _primary_of(records)
    return {
        "current": current,
        "raw": _pick(records, lambda item: "raw" in str(item.get("arm") or "").lower()),
        "rgb": _pick(records, lambda item: "rgb" in str(item.get("arm") or "").lower()),
    }


def sample_gpus() -> list[dict]:
    try:
        text = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=index,name,memory.used,memory.total,utilization.gpu",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True,
            text=True,
            timeout=8,
            check=False,
        ).stdout
    except (OSError, subprocess.SubprocessError):
        return []
    gpus = []
    for line in text.strip().splitlines():
        parts = [part.strip() for part in line.split(",")]
        if len(parts) < 5:
            continue
        index = _as_float(parts[0])
        gpus.append(
            {
                "index": int(index) if index is not None else parts[0],
                "name": parts[1],
                "memory_used_mib": _as_float(parts[2]),
                "memory_total_mib": _as_float(parts[3]),
                "utilization": _as_float(parts[4]),
            }
        )
    return gpus


def sample_cpu():
    try:
        load1, load5, load15 = os.getloadavg()
    except OSError:
        return None
    return {
        "load1": round(load1, 2),
        "load5": round(load5, 2),
        "load15": round(load15, 2),
        "cores": os.cpu_count(),
    }


def sampler_loop() -> None:
    while True:
        gpus, cpu = sample_gpus(), sample_cpu()
        with _LOCK:
            if gpus:
                _STATE["gpus"] = gpus
                _STATE["gpu_sampled_at"] = utc_now()
            _STATE["cpu"] = cpu
        time.sleep(GPU_SAMPLE_SECONDS)


def deployment_loop() -> None:
    path = Path(DOWNLOAD_STATUS_PATH)
    while True:
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(payload, dict):
                raise ValueError("downloads.json is not an object")
            clean = {}
            for repo, row in payload.items():
                row = row if isinstance(row, dict) else {}
                clean[str(repo)] = {
                    key: row.get(key)
                    for key in ("status", "path", "updated_at", "files", "bytes")
                    if key in row
                }
            with _LOCK:
                _STATE["deployment"] = clean
                _STATE["deployment_updated_at"] = utc_now()
        except (OSError, ValueError):
            pass
        time.sleep(DEPLOYMENT_REFRESH_SECONDS)


def read_history(run_dir: Path):
    path = run_dir / "history.jsonl"
    real = Path(os.path.realpath(path))
    run_real = Path(os.path.realpath(run_dir))
    if real != run_real and run_real not in real.parents:
        return None
    if not real.is_file():
        return []
    try:
        text = real.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    out = []
    for line in text.splitlines()[-HISTORY_MAX_RECORDS:]:
        line = line.strip()
        if not line:
            continue
        try:
            record = json.loads(line)
        except ValueError:
            continue
        if isinstance(record, dict):
            out.append(record)
    return out


def status_payload(root: Path) -> dict:
    records = snapshot_runs(root)
    with _LOCK:
        state = dict(_STATE)
    return {
        "updated_at": utc_now(),
        "stale_seconds": STALE_SECONDS,
        "run_root": str(root),
        "server": {
            "pid": os.getpid(),
            "started_at": state.get("server_started_at"),
            "port": _STATE.get("port"),
            "uptime_seconds": round(
                time.time() - (parse_iso(state.get("server_started_at")) or time.time()), 1
            ),
        },
        "gpus": state.get("gpus") or [],
        "gpu_sampled_at": state.get("gpu_sampled_at"),
        "gpu_sample_seconds": GPU_SAMPLE_SECONDS,
        "cpu": state.get("cpu"),
        "deployment": state.get("deployment") or {},
        "deployment_updated_at": state.get("deployment_updated_at"),
        "runs": records,
        "display": build_display(records),
    }


def training_payload(root: Path) -> dict:
    """Only explicitly selected current training runs; old probes never become results."""
    try:
        active = json.loads((root / "active_training.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        active = {}
    cards = []
    for selected in active.get("runs", [])[:2]:
        stage, run_id = selected.get("stage", "P2"), selected.get("run_id")
        if stage not in STAGES or not isinstance(run_id, str) or not RUN_ID_RE.fullmatch(run_id):
            continue
        directory, _ = resolve_run_dir(root, stage, run_id)
        record = load_run(root, stage, run_id) if directory is not None else None
        history = (read_history(directory) or []) if directory is not None else []
        curve = [
            {"step": r.get("step"), "error": r.get("dev_action_error")}
            for r in history
            if _as_float(r.get("dev_action_error")) is not None
        ]
        # Saving and completing can record the same dev step twice.
        curve = list({r["step"]: r for r in curve}.values())
        baseline = curve[0]["error"] if curve and curve[0]["step"] == 0 else None
        latest = curve[-1] if curve else None
        seconds = _as_float((record or {}).get("step_seconds"))
        effective = int(selected.get("effective_batch_size", 2))
        cards.append(
            {
                "label": selected.get("label", run_id),
                "run_id": run_id,
                "stage": stage,
                "state": (record or {}).get("state", "waiting"),
                "activity": (record or {}).get("activity", "等待启动"),
                "stale": (record or {}).get("stale", False),
                "updated_at": (record or {}).get("updated_at"),
                "step": (record or {}).get("step") or 0,
                "target": (record or {}).get("target_steps") or selected.get("target", 1000),
                "seconds_per_update": seconds,
                "samples_per_minute": 60 * effective / seconds if seconds and seconds > 0 else None,
                "eta_seconds": (record or {}).get("eta_seconds"),
                "loss": (record or {}).get("loss"),
                "latest_dev": latest,
                "baseline_dev": baseline,
                "best_dev": min(r["error"] for r in curve) if curve else None,
                "improvement_percent": 100 * (baseline - latest["error"]) / baseline
                if baseline and baseline > 0 and latest
                else None,
                "curve": curve,
                "gpu": (record or {}).get("gpu_detail", []),
                "checkpoint": (record or {}).get("checkpoint"),
            }
        )
    return {"updated_at": utc_now(), "title": active.get("title", "N02 训练"), "runs": cards}


class Handler(BaseHTTPRequestHandler):
    server_version = "n02-v12-monitor"
    run_root_override = None

    def _root(self) -> Path:
        return Path(self.run_root_override or run_root())

    def _send(self, code, body: bytes, content_type: str) -> None:
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, code, payload) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self._send(code, body, "application/json; charset=utf-8")

    def _query(self) -> dict:
        parsed = urllib.parse.urlparse(self.path)
        return {key: values[-1] for key, values in urllib.parse.parse_qs(parsed.query).items()}

    def _reject(self, reason: str, run_id=None) -> None:
        code = 404 if reason in ("run not found", "unknown stage") else 400
        self._json(code, {"error": reason, "run_id": run_id})

    def do_GET(self) -> None:  # noqa: N802
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"
        try:
            if path in ("/", "/index.html", "/details"):
                html_path = Path(__file__).with_name("n02_v12_monitor.html")
                if path != "/details":
                    html_path = Path(__file__).with_name("n02_v12_training.html")
                self._send(200, html_path.read_bytes(), "text/html; charset=utf-8")
                return
            if path == "/favicon.ico":
                self._send(204, b"", "image/x-icon")
                return
            if path == "/api/status":
                self._json(200, status_payload(self._root()))
                return
            if path == "/api/training":
                self._json(200, training_payload(self._root()))
                return
            if path == "/api/history":
                query = self._query()
                if query.get("stage") is None:
                    run_dir, error = self._locate(query.get("run_id"))
                else:
                    run_dir, error = resolve_run_dir(
                        self._root(), query.get("stage"), query.get("run_id")
                    )
                if run_dir is None:
                    self._reject(error, query.get("run_id"))
                    return
                records = read_history(run_dir)
                self._json(200, records if records is not None else [])
                return
            if path == "/api/preview":
                self._serve_preview()
                return
            self._json(404, {"error": "not found"})
        except (BrokenPipeError, ConnectionResetError):
            return
        except OSError:
            self._json(500, {"error": "internal error"})

    def _locate(self, run_id):
        """history 接口允许只给 run_id（在 stage 白名单里逐个找）。"""
        if not isinstance(run_id, str) or not RUN_ID_RE.match(run_id) or run_id in (".", ".."):
            return None, "invalid run_id"
        for stage in STAGES:
            run_dir, error = resolve_run_dir(self._root(), stage, run_id)
            if run_dir is not None:
                return run_dir, None
        return None, "run not found"

    def _serve_preview(self) -> None:
        query = self._query()
        run_id, relative = query.get("run_id"), query.get("file")
        run_dir, error = self._locate(run_id)
        if run_dir is None:
            self._reject(error, run_id)
            return
        if not isinstance(relative, str) or not relative.strip() or "\x00" in relative:
            self._reject("invalid file", run_id)
            return
        candidate = Path(relative)
        if candidate.is_absolute() or ".." in candidate.parts:
            self._reject("invalid file", run_id)
            return
        target = Path(os.path.realpath(run_dir / candidate))
        if target != run_dir and run_dir not in target.parents:
            self._reject("invalid file", run_id)
            return
        if target.suffix.lower() not in IMAGE_SUFFIXES or not target.is_file():
            self._reject("invalid file", run_id)
            return
        suffix = target.suffix.lower()
        content_type = {
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".webp": "image/webp",
            ".gif": "image/gif",
            ".svg": "image/svg+xml",
        }[suffix]
        self._send(200, target.read_bytes(), content_type)

    def do_HEAD(self) -> None:  # noqa: N802
        self.do_GET()

    def do_POST(self) -> None:  # noqa: N802
        self._json(405, {"error": "read-only monitor: POST not allowed"})

    def log_message(self, fmt, *args) -> None:  # noqa: A003
        return


def main() -> int:
    parser = argparse.ArgumentParser(description="N02 v1.2 read-only monitor")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=18080)
    parser.add_argument("--run-root", default=None)
    args = parser.parse_args()

    if args.run_root:
        os.environ["N02_V12_RUN_ROOT"] = args.run_root
    root = run_root()
    root.mkdir(parents=True, exist_ok=True)

    with _LOCK:
        _STATE["server_started_at"] = utc_now()
        _STATE["port"] = args.port
    Handler.run_root_override = str(root)

    threading.Thread(target=sampler_loop, daemon=True).start()
    threading.Thread(target=deployment_loop, daemon=True).start()

    while True:
        try:
            httpd = ThreadingHTTPServer((args.host, args.port), Handler)
            break
        except OSError as exc:
            print(f"[monitor] bind {args.host}:{args.port} failed ({exc}); retry in 5s", flush=True)
            time.sleep(5)
    print(
        f"[monitor] serving http://{args.host}:{args.port}/ run_root={root} pid={os.getpid()}",
        flush=True,
    )
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
