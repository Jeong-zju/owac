"""The simple view must never substitute historical probes for the current experiment."""

import json

from owac.runtime import n02_v12_monitor as monitor
from owac.runtime.n02_v12_status import append_history, update_status


def test_current_training_selection_and_persistent_validation(tmp_path):
    root = tmp_path
    old = root / "P2" / "old-profile"
    update_status(old, run_id="old-profile", stage="P2", state="completed", step=1000)
    active = root / "P2" / "current-raw"
    update_status(
        active,
        run_id="current-raw",
        stage="P2",
        state="running",
        step=12,
        target_steps=1000,
        step_seconds=4.0,
        dev_action_error=None,
    )
    append_history(active, step=0, wall_time=0, train_loss=None, dev_action_error=2.0)
    append_history(active, step=10, wall_time=40, train_loss=1.0, dev_action_error=0.5)
    append_history(active, step=12, wall_time=48, train_loss=0.9, dev_action_error=None)
    (root / "active_training.json").write_text(
        json.dumps(
            {
                "runs": [
                    {
                        "run_id": "current-raw",
                        "stage": "P2",
                        "label": "RAW 模型",
                        "effective_batch_size": 2,
                    },
                    {"run_id": "current-rgb", "stage": "P2", "label": "RGB 对照"},
                ]
            }
        )
    )
    result = monitor.training_payload(root)
    assert [r["run_id"] for r in result["runs"]] == ["current-raw", "current-rgb"]
    raw, rgb = result["runs"]
    assert raw["latest_dev"] == {"step": 10, "error": 0.5}
    assert raw["improvement_percent"] == 75.0
    assert raw["samples_per_minute"] == 30.0
    assert rgb["state"] == "waiting" and rgb["latest_dev"] is None


def test_bad_run_reference_does_not_read_outside_root(tmp_path):
    (tmp_path / "active_training.json").write_text(
        json.dumps(
            {
                "runs": [
                    {"run_id": "../outside", "stage": "P2"},
                    {"run_id": "raw", "stage": "../../outside"},
                ]
            }
        )
    )
    assert monitor.training_payload(tmp_path)["runs"] == []
