"""N02 v1.2 P2 evaluation-entry tests (CPU, tiny real modules, no dataset, no GPU).

They check the parts the acceptance depends on and that a green import cannot show:

* the declared viewing rule really matches the views the frozen inference builds, so the
  three-state check is *valid* instead of silently invalid;
* a mismatched label is an explicit failure, and a missing calibrator is counted separately,
  never as a zero and never as the string ``None``;
* settings resolution tolerates a missing/hand-written config, and the fixed dev sample receipt
  is reused instead of silently re-sampling;
* the diagnostic figures are produced from the real tensors and carry the required labels.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pytest
import torch

from owac.core.encoder_contract import EmbodimentContext, MeasurementFrame
from owac.evaluation.n02_full import v12 as v12_eval
from owac.evaluation.n02_full import v12_viz
from owac.frameworks.n02_full.checks import STATUSES, ViewingRule, select_views
from owac.frameworks.n02_full.checks_v12 import (
    AbsoluteCheckResult,
    calibrate_windowed,
    summarise_results,
)
from owac.frameworks.n02_full.model_v12 import build_n02_v12_model
from owac.frameworks.n02_full.state import ObservationBundle

CAMERAS = ("cam_a", "cam_b")
SIDE = 32
ROWS = 3


def tiny_settings(**overrides) -> dict:
    settings = {
        "camera_ids": CAMERAS,
        "dims": (8, 16, 32, 64),
        "depths": (1, 1, 1, 1),
        "d_model": 32,
        "k": 3,
        "n_slots": 2,
        "slot_dim": 8,
        "rounds": 2,
        "history": 8,
        "query_stride": 8,
        "alignment": 32,
        "input_mode": "RAW3",
        "measurement_channels": 3,
        "decoder_hidden": 16,
        "n_latents": 4,
        "n_queries": 8,
        "out_dim": 32,
        "strict_check": True,
    }
    settings.update(overrides)
    return settings


def tiny_model(**overrides):
    torch.manual_seed(1103)
    return build_n02_v12_model(tiny_settings(**overrides))


def bundle(
    seed: int = 0, *, rows: int = ROWS, side: int = SIDE, cameras=CAMERAS
) -> ObservationBundle:
    generator = torch.Generator().manual_seed(seed)
    frames = {}
    for camera in cameras:
        frames[camera] = MeasurementFrame(
            values=torch.randn(rows, 3, side, side, generator=generator) * 0.25 + 0.5,
            valid_mask=torch.ones(rows, side, side, dtype=torch.bool),
            camera_id=camera,
            frame_ids=tuple(f"{1000 + row}" for row in range(rows)),
            episode_ids=tuple("episode_007" for _ in range(rows)),
            metadata={"declared_units": "unit_test"},
        )
    return ObservationBundle(
        frames=frames,
        context=EmbodimentContext(proprio=np.zeros((rows, 8), np.float32), proprio_available=True),
        episode_ids=tuple("episode_007" for _ in range(rows)),
        anchor_ids=tuple(f"episode_007#anchor{1000 + row:06d}" for row in range(rows)),
    )


class FakeBatch:
    """The three fields ``v12`` reads off a served window batch."""

    def __init__(
        self, observation=None, *, rows: int = ROWS, frame_start: int = 1000, seed: int = 0
    ):
        self.observation = bundle(seed, rows=rows) if observation is None else observation
        self.frame_index = np.arange(frame_start, frame_start + rows, dtype=np.int64)
        self.measurement_ids = tuple(
            (f"episode_{index:03d}", str(camera), str(frame_start + row))
            for row in range(rows)
            for index, camera in enumerate(CAMERAS)
        )
        self.declared_prior = None
        self.partition = "dev"


class FakeRecord:
    def __init__(self, payload: dict):
        self._payload = payload

    def as_dict(self) -> dict:
        return dict(self._payload)


class FakeSource:
    def __init__(self, total: int):
        self.anchor_count = total

    def anchor(self, index: int) -> FakeRecord:
        return FakeRecord(
            {
                "relative_path": f"libero/raw/task_{index:03d}.npz",
                "current_frame_index": 10 + index,
                "episode_group_id": f"episode_{index:03d}",
            }
        )


def _contains_none_string(payload) -> bool:
    if isinstance(payload, str):
        return payload == "None"
    if isinstance(payload, dict):
        return any(_contains_none_string(value) for value in payload.values())
    if isinstance(payload, (list, tuple)):
        return any(_contains_none_string(value) for value in payload)
    return False


# ---------------------------------------------------------------------------------------
# the check rule really matches the frozen views
# ---------------------------------------------------------------------------------------


def test_check_rule_matches_the_views_the_frozen_inference_builds() -> None:
    model = tiny_model()
    settings = v12_eval.resolve_settings(
        v12_eval.build_parser().parse_args(["--dataset-format", "robotwin"])
    )
    settings.model = tiny_settings()
    rule = v12_eval.build_check_rule(settings)
    assert rule.scales == ("sensor_stride8",)
    assert rule.frames == (0,)
    assert set(rule.regions) == set(CAMERAS)
    assert rule.use_local_maximum is False

    batch = FakeBatch()
    state = model.build_state(batch=1)
    observation = v12_eval.row_observation(batch.observation, ROWS - 1)
    # the real-frame pass labels the views with the real frame index: the frozen rule (which is
    # shared between calibration and dev) cannot name it, and that is stated, not hidden
    real_inp = v12_eval.inference_input(batch, observation=observation, rows=[ROWS - 1])
    real_output = model.step(real_inp, state)
    real_locked = v12_eval.locked_residual_groups(model.inference, real_inp, state, real_output.q)
    real_frame = int(batch.frame_index[-1])
    assert real_locked["labels"][0] == [
        ("sensor_stride8", real_frame, "cam_a"),
        ("sensor_stride8", real_frame, "cam_b"),
    ]
    with pytest.raises(Exception, match="viewing rule"):
        select_views(real_locked["groups"][0], rule=rule)

    # the check-labelled pass declares the constant window label, so the rule selects exactly
    # those views (the real identity stays in the declared measurement ids)
    check_inp = v12_eval.inference_input(
        batch, observation=observation, rows=[ROWS - 1], frame_label=0
    )
    check_output = model.step(check_inp, state)
    locked = v12_eval.locked_residual_groups(model.inference, check_inp, state, check_output.q)
    assert locked["labels"][0] == [
        ("sensor_stride8", 0, "cam_a"),
        ("sensor_stride8", 0, "cam_b"),
    ]
    assert len(select_views(locked["groups"][0], rule=rule)) == 2
    assert all(item.startswith("episode_007/cam_") for item in locked["measurement_ids"]), locked[
        "measurement_ids"
    ]


def test_calibrated_check_is_valid_and_uncalibrated_is_counted_separately() -> None:
    model = tiny_model()
    rule = ViewingRule(
        scales=("sensor_stride8",), frames=(0,), regions=CAMERAS, window=4, use_local_maximum=False
    )
    groups, ids = [], []
    for seed in range(6):
        batch = FakeBatch(seed=seed)
        state = model.build_state(batch=1)
        observation = v12_eval.row_observation(batch.observation, ROWS - 1)
        inp = v12_eval.inference_input(
            batch, observation=observation, rows=[ROWS - 1], frame_label=0
        )
        output = model.step(inp, state)
        locked = v12_eval.locked_residual_groups(model.inference, inp, state, output.q)
        groups.extend(locked["groups"])
        ids.extend(locked["measurement_ids"])
    frozen = calibrate_windowed(
        groups, partition="calibration", rule=rule, calibration_ids=ids, test_ids=[]
    )
    assert np.isfinite(frozen.threshold)

    model.inference.calibrator = frozen
    batch = FakeBatch(seed=99)
    state = model.build_state(batch=1)
    observation = v12_eval.row_observation(batch.observation, ROWS - 1)
    inp = v12_eval.inference_input(batch, observation=observation, rows=[ROWS - 1], frame_label=0)
    checked = model.step(inp, state)
    assert checked.check.valid is True
    assert checked.check.status in STATUSES
    summary = summarise_results([checked.check])
    assert summary["total"] == 1 and summary["valid"] == 1 and summary["invalid"] == 0

    model.inference.calibrator = None
    uncalibrated = model.step(
        v12_eval.inference_input(batch, observation=observation, rows=[ROWS - 1], frame_label=0),
        state,
    )
    assert uncalibrated.check.valid is False
    record = v12_eval.check_record(uncalibrated.check)
    assert record["valid"] is False
    assert record["statistics"]["reason"] == "no_fitted_calibrator"
    assert not _contains_none_string(record)
    separate = summarise_results([uncalibrated.check])
    assert separate["invalid"] == 1
    assert separate["compatible"] == 0 and separate["model_inadequate"] == 0


def test_a_label_that_does_not_match_the_frozen_rule_is_an_explicit_failure() -> None:
    model = tiny_model()
    batch = FakeBatch()
    state = model.build_state(batch=1)
    observation = v12_eval.row_observation(batch.observation, ROWS - 1)
    rule = ViewingRule(
        scales=("sensor_stride8",), frames=(0,), regions=CAMERAS, window=4, use_local_maximum=False
    )
    groups, ids = [], []
    for seed in range(4):
        item = FakeBatch(seed=seed)
        item_state = model.build_state(batch=1)
        obs = v12_eval.row_observation(item.observation, ROWS - 1)
        inp = v12_eval.inference_input(item, observation=obs, rows=[ROWS - 1], frame_label=0)
        output = model.step(inp, item_state)
        locked = v12_eval.locked_residual_groups(model.inference, inp, item_state, output.q)
        groups.extend(locked["groups"])
        ids.extend(locked["measurement_ids"])
    model.inference.calibrator = calibrate_windowed(
        groups, partition="calibration", rule=rule, calibration_ids=ids, test_ids=[]
    )
    with pytest.raises(Exception) as excinfo:
        model.step(
            v12_eval.inference_input(
                batch, observation=observation, rows=[ROWS - 1], frame_label=4242
            ),
            state,
        )
    assert "viewing rule" in str(excinfo.value)


def test_invalid_results_never_enter_the_status_counts() -> None:
    valid = AbsoluteCheckResult(
        status="compatible",
        valid=True,
        statistics={"sequence_statistic": 0.2},
        calibration_version="test",
    )
    invalid = AbsoluteCheckResult.invalid(reason="no_fitted_calibrator")
    summary = summarise_results([valid, invalid])
    assert summary["compatible"] == 1 and summary["invalid"] == 1
    assert invalid.counted_as_false_positive is False
    assert invalid.counted_as_detection is False
    assert not _contains_none_string(summary)


# ---------------------------------------------------------------------------------------
# replay and settings
# ---------------------------------------------------------------------------------------


def test_replay_window_chains_the_state_and_checks_the_anchor_row() -> None:
    model = tiny_model()
    batch = FakeBatch()
    replay = v12_eval.replay_window(model, batch, device="cpu", check_label=0, check=True)
    assert len(replay["rows"]) == ROWS
    assert replay["check_backend"] is not None
    first_state = replay["rows"][0].state
    last_state = replay["rows"][-1].state
    assert last_state.version >= first_state.version
    assert int(last_state.slot_hidden.shape[0]) == 1
    # the check step declares the constant window label, and the real frame identity survives in
    # the measurement ids of the check step
    observation = v12_eval.row_observation(batch.observation, ROWS - 1)
    inp = v12_eval.inference_input(batch, observation=observation, rows=[ROWS - 1], frame_label=0)
    assert [int(item) for item in inp.frame_index.tolist()] == [0]
    assert all(item[2] == str(int(batch.frame_index[-1])) for item in inp.measurement_ids), (
        inp.measurement_ids
    )
    real_inp = v12_eval.inference_input(batch, observation=observation, rows=[ROWS - 1])
    assert [int(item) for item in real_inp.frame_index.tolist()] == [int(batch.frame_index[-1])]


def test_resolve_settings_tolerates_missing_and_nested_configs(tmp_path: Path) -> None:
    parser = v12_eval.build_parser()
    missing = tmp_path / "not_here.json"
    settings = v12_eval.resolve_settings(
        parser.parse_args(["--config", str(missing), "--output", str(tmp_path / "eval")])
    )
    assert settings.config_present is False
    assert settings.dataset_format == "robotwin"
    assert settings.camera_ids() == ("robotwin_head", "robotwin_left", "robotwin_right")
    assert settings.preview_dir == str(tmp_path / "preview")

    nested = tmp_path / "config.json"
    nested.write_text(
        json.dumps(
            {
                "run": {"name": "raw-n02"},
                "data": {"dataset_format": "libero", "data_root": "/data/rawvla"},
                "model": {"k": 2, "query_stride": 16, "n_queries": 4},
            }
        ),
        encoding="utf-8",
    )
    settings = v12_eval.resolve_settings(
        parser.parse_args(["--config", str(nested), "--output", str(tmp_path / "eval")])
    )
    assert settings.config_present is True and settings.config_sha256
    assert settings.dataset_format == "libero"
    assert settings.data_root == "/data/rawvla"
    assert settings.camera_ids() == ("libero_agentview", "libero_wrist")
    assert settings.query_stride == 16
    assert settings.model["k"] == 2 and settings.model["n_queries"] == 4

    unknown = tmp_path / "unknown.json"
    unknown.write_text(json.dumps({"dataset_format": "nope"}), encoding="utf-8")
    settings = v12_eval.resolve_settings(parser.parse_args(["--config", str(unknown)]))
    assert settings.dataset_format == "robotwin"
    assert any("not a known cache format" in note for note in settings.notes)


def test_config_checkpoints_are_not_confused(tmp_path: Path) -> None:
    """The config's ``policy.checkpoint`` is the pi0.5 backend, never the N02 model weights."""
    parser = v12_eval.build_parser()
    config = tmp_path / "raw_n02_robotwin.json"
    config.write_text(
        json.dumps(
            {
                "platform": "robotwin",
                "model": {"k": 2},
                "policy": {"checkpoint": "/backend/pi05/model.safetensors"},
                "paths": {"output_root": "/tmp/runs"},
            }
        ),
        encoding="utf-8",
    )
    settings = v12_eval.resolve_settings(parser.parse_args(["--config", str(config)]))
    assert settings.checkpoint is None
    assert settings.backend_checkpoint == "/backend/pi05/model.safetensors"

    model_config = tmp_path / "with_model_config.json"
    model_config.write_text(json.dumps({"model": {"checkpoint": "/runs/x.pt"}}), encoding="utf-8")
    settings = v12_eval.resolve_settings(parser.parse_args(["--config", str(model_config)]))
    assert settings.checkpoint == "/runs/x.pt"


def test_a_safetensors_file_is_never_torch_loaded(tmp_path: Path) -> None:
    model = tiny_model()
    bad = tmp_path / "model.safetensors"
    bad.write_bytes(b"not a torch checkpoint")
    receipt = v12_eval.load_checkpoint_into(model, bad)
    assert receipt["loaded"] is False
    assert "not a torch checkpoint" in receipt["reason"]

    broken = tmp_path / "broken.pt"
    broken.write_bytes(b"not a torch checkpoint either")
    receipt = v12_eval.load_checkpoint_into(model, broken)
    assert receipt["loaded"] is False and receipt["reason"]


def test_model_step_prefers_the_file_then_the_flag_then_stays_unknown(tmp_path: Path) -> None:
    """The label names the real step: the file's step, else ``--model-step``, else unknown."""
    model = tiny_model()
    weights = dict(model.state_dict())

    with_step = tmp_path / "with_step.pt"
    torch.save({"model": {"step": 1000, "global_step": 4242, **weights}}, with_step)
    receipt = v12_eval.load_checkpoint_into(model, with_step)
    assert receipt["loaded"] is True
    assert receipt["training_step_recorded_in_file"] == 1000
    assert v12_eval.resolve_model_step(receipt["training_step_recorded_in_file"], 7) == 1000

    bare = tmp_path / "bare_state_dict.pt"
    torch.save(weights, bare)
    receipt = v12_eval.load_checkpoint_into(model, bare)
    assert receipt["loaded"] is True
    assert receipt["training_step_recorded_in_file"] is None
    assert v12_eval.resolve_model_step(receipt["training_step_recorded_in_file"], 1000) == 1000

    assert v12_eval.resolve_model_step(None, None) is None
    identity = {"episode_group_id": "episode_007"}
    unknown = v12_viz._labels(None, identity, CAMERAS[0], 0, 0, None)
    assert "model step=unknown" in unknown
    assert "model step=1000" in v12_viz._labels(None, identity, CAMERAS[0], 0, 0, 1000)

    for parser in (v12_eval.build_parser(), v12_viz.build_parser()):
        assert parser.parse_args([]).model_step is None
        assert parser.parse_args(["--model-step", "1000"]).model_step == 1000


def test_anchor_indices_and_frozen_sample_receipt(tmp_path: Path) -> None:
    source = FakeSource(101)
    indices = v12_eval.anchor_indices(source, 5)
    assert indices == sorted(set(indices))
    assert all(0 <= item < 101 for item in indices)
    assert v12_eval.anchor_indices(source, 5) == indices

    path = tmp_path / "dev_samples.json"
    first_indices, first = v12_eval.fixed_sample_identities(
        source, 3, path=path, partition="dev", frozen=None
    )
    assert first["source"] == "frozen_now" and path.is_file()
    payload = json.loads(path.read_text(encoding="utf-8"))
    second_indices, second = v12_eval.fixed_sample_identities(
        source, 3, path=path, partition="dev", frozen=payload["identities"]
    )
    assert second_indices == first_indices
    assert second["source"] == "frozen_receipt"
    assert [item["anchor_index"] for item in second["identities"]] == first_indices


# ---------------------------------------------------------------------------------------
# report and figure plumbing
# ---------------------------------------------------------------------------------------


def test_jsonable_is_json_safe_and_compact() -> None:
    payload = {
        "nan": float("nan"),
        "inf": float("inf"),
        "tensor": torch.zeros(3),
        "long": list(range(100)),
        "path": Path("/tmp/x"),
    }
    safe = v12_eval._jsonable(payload)
    text = json.dumps(safe, allow_nan=False)
    assert safe["nan"] is None and safe["inf"] is None
    assert safe["long"]["count"] == 100 and safe["long"]["min"] == 0
    assert safe["tensor"] == [0.0, 0.0, 0.0]
    assert isinstance(text, str) and "None" not in text.replace('"None"', "")


def test_png_bytes_is_a_real_png() -> None:
    image = np.zeros((4, 5, 3), dtype=np.uint8)
    image[..., 0] = 255
    data = v12_viz.png_bytes(image)
    assert data.startswith(b"\x89PNG\r\n\x1a\n")
    assert b"IHDR" in data and b"IEND" in data
    with pytest.raises(ValueError):
        v12_viz.png_bytes(np.zeros((2, 2, 2), dtype=np.uint8))


def test_figures_carry_identity_labels_and_real_tensors(tmp_path: Path) -> None:
    model = tiny_model()
    batch = FakeBatch()
    replay = v12_eval.replay_window(model, batch, device="cpu", check_label=0, check=True)
    capture = v12_viz._anchor_capture(model, batch, device="cpu", replay=replay)
    capture["model"] = model
    capture["stride"] = 8
    attention = v12_viz._attention_maps(capture, None)
    assert attention["available"] is True
    for camera in CAMERAS:
        entry = attention[camera]
        assert entry["coords"].shape[0] == entry["attention"].shape[0]
        assert entry["coords"].shape[0] > 0
    labels = v12_viz._labels(None, {"episode_group_id": "episode_007"}, CAMERAS[0], 1234, 1, 1000)
    for key in ("episode=", "camera=", "frame=", "iteration=", "model step="):
        assert key in labels

    frame = v12_eval.row_observation(batch.observation, ROWS - 1).frames[CAMERAS[0]]
    svg = v12_viz.figure_raw_display(
        frame,
        camera_id=CAMERAS[0],
        labels=labels,
        title="unit test raw",
        white_level=1.0,
        gamma=2.2,
        gains=[1.0, 1.0, 1.0],
        zoom_box=(0, 8, 0, 8),
        max_side=48,
    )
    assert svg.startswith(b"<svg") and b"<image" in svg and b"same-source RGB" in svg
    assert b"episode=episode_007" in svg

    svg = v12_viz.figure_attention(
        frame,
        attention,
        camera_id=CAMERAS[0],
        labels=labels,
        title="unit test attention",
        white_level=1.0,
        max_side=48,
    )
    assert b"cross-attention" in svg and b"<image" in svg

    svg = v12_viz.figure_prediction(
        capture,
        frame,
        camera_id=CAMERAS[0],
        camera_slot=0,
        labels=labels,
        title="unit test prediction",
        max_side=48,
    )
    assert b"candidate RAW prediction" in svg

    svg = v12_viz.figure_rounds(
        replay["rows"][-1], labels=labels, title="unit test rounds", rounds=2
    )
    assert b"final support" in svg

    svg = v12_viz.figure_actions(
        None,
        np.zeros((10, 7), dtype=np.float64),
        labels=labels,
        title="unit test actions",
        control_dim=7,
        reason="unit test backend absent",
    )
    assert b"prediction unavailable" in svg and b"reference dim 0" in svg


def test_attention_figure_says_so_when_the_tensor_is_absent(tmp_path: Path) -> None:
    frame = MeasurementFrame(values=np.zeros((3, 8, 8), np.float32), camera_id="cam_a")
    svg = v12_viz.figure_attention(
        frame,
        {"available": False, "reason": "no tensor"},
        camera_id="cam_a",
        labels="episode=x camera=cam_a frame=0 iteration=0 model step=none",
        title="missing attention",
        white_level=1.0,
        max_side=32,
    )
    assert b"attention tensor unavailable" in svg


def test_preview_files_are_named_relative_to_the_run_dir(tmp_path: Path) -> None:
    run = tmp_path / "run"
    preview = run / "preview"
    preview.mkdir(parents=True)
    (preview / "01_raw_rgb_zoom_000_cam_a.svg").write_text("<svg/>", encoding="utf-8")
    (preview / "figures.json").write_text("{}", encoding="utf-8")
    files = v12_eval._preview_files(preview)
    assert files == ["preview/01_raw_rgb_zoom_000_cam_a.svg"]
